package reflection_and_annotation.barracksWars.core.commands;

import jdk.jshell.spi.ExecutionControl;
import reflection_and_annotation.barracksWars.interfaces.Repository;
import reflection_and_annotation.barracksWars.interfaces.UnitFactory;

public class RetireCommand extends Command {

    public RetireCommand(String[] data, Repository repository, UnitFactory unitFactory) {
        super(data, repository, unitFactory);
    }

    @Override
    public String execute() throws ExecutionControl.NotImplementedException {
        String unitType = getData()[1];

        getRepository().removeUnit(unitType);

        return unitType + " retired!";
    }
}
