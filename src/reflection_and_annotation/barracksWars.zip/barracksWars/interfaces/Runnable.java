package reflection_and_annotation.barracksWars.interfaces;

public interface Runnable {
	void run();
}
