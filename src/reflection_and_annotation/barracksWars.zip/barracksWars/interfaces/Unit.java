package reflection_and_annotation.barracksWars.interfaces;

public interface Unit extends Destroyable, Attacker {
}
